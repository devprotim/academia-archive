<footer class="bg-dark text-white py-3">
    <div class="container">
        <p class="text-center mb-0">&copy; <?php echo date('Y'); ?> Assam University.</p>
    </div>
</footer>
</body>

</html>