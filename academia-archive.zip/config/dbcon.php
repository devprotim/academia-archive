<?php

define("HOSTNAME", "localhost");
define("USERNAME", "pspmuser");
define("PASSWORD", "Pspm@2024");
define("DATABASE", "pspm");

$connection = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE);

if (!$connection) {
    die("Connection Failed");
} else {
    // echo "Connected";
}
